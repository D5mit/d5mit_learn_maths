from setuptools import setup

setup(name='d5mit_learn_maths',
      version='0.1',
      description='Gaussian distributions',
      packages=['d5mit_learn_maths'],
      zip_safe=False)
